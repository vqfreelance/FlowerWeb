﻿namespace JavaFlorist.Models.EFCore
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}